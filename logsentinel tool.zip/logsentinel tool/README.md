# 🛡️ LogSentinel — Multi-Format Intrusion Detection System

A browser-based, zero-dependency log analysis tool that automatically detects security threats across 7 log formats and 6 attack categories. No server, no install — drop a log file and get results instantly.

---

## 📁 Project Structure

```
logsentinel/
├── index.html                  ← Main HTML page (markup only)
├── css/
│   └── styles.css              ← All visual styles — no inline CSS anywhere
├── js/
│   ├── main.js                 ← Entry point — event listeners only
│   ├── state.js                ← Shared state, constants, regex patterns, blacklist
│   ├── parser.js               ← Log parsing engine — 8 format handlers
│   ├── detector.js             ← Threat detection — 6 categories, 25+ detectors
│   ├── charts.js               ← 5 Chart.js visualizations
│   └── ui.js                   ← DOM rendering, filters, exports, log viewer
├── sample_logs/                ← Ready-to-drop test files for each format
│   ├── apache_access.log       ← Web access log (Combined Log Format)
│   ├── apache_error.log        ← Apache error log
│   ├── ssh_auth.log            ← SSH authentication log (auth.log)
│   ├── syslog.log              ← System log with privilege escalation events
│   ├── firewall_ufw.log        ← UFW firewall log with port scan
│   └── application.log        ← Structured application log
└── README.md
```

---

## 🚀 How to Run

ES modules require a web server (`file://` protocol will not work):

```bash
# Python 3 (easiest — no install needed)
cd logsentinel
python3 -m http.server 8080
# Open http://localhost:8080

# Node.js
npx serve .

# VS Code: right-click index.html then Open with Live Server
```

---

## 📋 Supported Log Formats

| Format | Key Data Extracted |
|--------|--------------------|
| Apache Access Log (CLF) | IP, method, path, status, size |
| Apache Access Log (Combined) | + user-agent, referrer |
| Apache Error Log | Client IP, level, error messages |
| SSH Authentication Log | Brute force, accepted/failed events |
| System Log / syslog | Privilege escalation, sudo, user creation |
| Firewall Log (UFW / iptables) | Port scans, floods, BLOCK/ALLOW actions |
| Application Log | ISO timestamp + structured level + message |
| OpenStack Nova | API abuse, component errors, power desyncs |

---

## 🔥 Threat Detection Categories

### Category 1 — Brute Force
BRUTE_FORCE_SSH · ROOT_BRUTE_FORCE · ROOT_LOGIN_SUCCESS · ACCOUNT_COMPROMISE · WEB_BRUTE_FORCE · CREDENTIAL_STUFFING · ODD_HOUR_LOGIN

### Category 2 — Reconnaissance
SCANNING_404 · ADMIN_PROBE · ENDPOINT_SCAN · PORT_SCAN · NETWORK_SWEEP

### Category 3 — DoS
HTTP_FLOOD · FIREWALL_FLOOD · ERROR_STORM

### Category 4 — Exploitation
SQL_INJECTION · XSS_ATTEMPT · DIRECTORY_TRAVERSAL · COMMAND_INJECTION · ENCODED_ATTACK · MALICIOUS_USER_AGENT

### Category 5 — Privilege Escalation
SUDO_ABUSE · SUSPICIOUS_SUDO_CMD · NEW_USER_CREATED · PASSWORD_CHANGED · NEW_GROUP_CREATED

### Category 6 — Blacklisted IP
BLACKLISTED_IP (cross-referenced against offline Emerging Threats / Spamhaus list)

---

## 📊 Visualizations

1. Top IPs by Event Volume (bar chart, red = alerted IP)
2. Activity Timeline (5-min bins, total vs threat events)
3. HTTP Status Codes / Log Level Distribution (adaptive)
4. Alerts by Attack Category (doughnut)
5. Alerts by Severity (doughnut)

---

## 📤 Exports

JSON · CSV · Standalone HTML Report with category summary cards

---

## 🛠️ Extending

To add a new detector: add a function in detector.js and register it in detectThreats().
To add a new format: add a regex in parser.js and a new branch in parseLine().
To adjust thresholds: edit the T object at the top of detector.js.
