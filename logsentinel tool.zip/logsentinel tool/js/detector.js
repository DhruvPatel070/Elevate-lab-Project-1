/**
 * detector.js
 * Threat detection engine — 6 attack categories, 25 individual detectors.
 *
 * Cat 1 BRUTE_FORCE          — SSH/web brute force, credential stuffing, root attacks
 * Cat 2 RECONNAISSANCE       — 404 floods, admin probing, port scans, endpoint scanning
 * Cat 3 DOS                  — HTTP flood, firewall flood, error storms
 * Cat 4 EXPLOITATION         — SQLi, XSS, traversal, CMDi, encoded attacks, bad agents
 * Cat 5 PRIVILEGE_ESCALATION — sudo abuse, new user, root login, passwd change
 * Cat 6 BLACKLISTED_IP       — offline IP blacklist cross-reference
 */

import { state, BLACKLIST, SEV_ORDER, SQLI, XSS, TRAVERSAL, CMDI, ENCODED_ATTACK, BAD_AGENTS, ADMIN_PATHS } from './state.js';
import { groupBy } from './parser.js';

// ─────────────────────────── TUNABLE THRESHOLDS ──────────────────────────────
const T = {
  // Category 1 — Brute Force
  sshFailWindow:   300_000,  // 5-minute rolling window
  sshFailMin:      5,        // failed logins in window → HIGH
  sshFailTotal:    10,       // OR this total → HIGH
  webAuthFailMin:  8,        // 401/403 hits on login paths in window → HIGH
  webAuthWindow:   300_000,
  credStuffUsers:  3,        // distinct usernames from one IP → HIGH
  unusualHourStart:0,        // midnight
  unusualHourEnd:  5,        // 5am — successful logins flagged MEDIUM

  // Category 2 — Recon
  notFoundMin:     12,       // 404s from one IP → MEDIUM
  adminProbeMin:   4,        // admin path hits → MEDIUM
  endpointScanMin: 20,       // distinct paths in 2 min → MEDIUM
  portScanMin:     5,        // distinct blocked dest ports → HIGH

  // Category 3 — DoS
  httpFloodMin:    80,       // requests per 60-second window → HIGH
  httpFloodWindow: 60_000,
  fwFloodMin:      30,       // blocked packets / min → HIGH
  errorStormCount: 20,       // 4xx/5xx requests from one IP
  errorStormRatio: 0.70,     // error rate → MEDIUM

  // Category 4 — Exploitation (any hit = alert)
  // Category 5 — Privilege escalation
  sudoFailMin:     3,        // sudo failures per user → HIGH

  // Anomaly
  apacheErrMin:    10,       // apache errors per IP → LOW
};

// ─────────────────────────── HELPERS ─────────────────────────────────────────

/** Max items within a sliding window (sortedTs must be ascending) */
function maxInWindow(sortedTs, windowMs) {
  if (sortedTs.length < 2) return sortedTs.length;
  let max=1, cur=1;
  for (let i=1; i<sortedTs.length; i++) {
    cur = sortedTs[i]-sortedTs[i-1] < windowMs ? cur+1 : 1;
    if (cur>max) max=cur;
  }
  return max;
}

const fts = ts => ts ? new Date(ts).toLocaleString() : '—';

function mkAlert(type, severity, category, ip, count, first, last, description, extras={}) {
  return { type, severity, category, ip:ip||'N/A', count:count??null,
           first:first||'—', last:last||'—', description, ...extras };
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 1 — BRUTE FORCE
// ═════════════════════════════════════════════════════════════════════════════

function detectSSHBruteForce() {
  const out    = [];
  const failed = state.parsedData.ssh.filter(e=>['failed','invalid','toomany'].includes(e.event));
  const byIP   = groupBy(failed.filter(e=>e.ip), 'ip');
  for (const [ip, evs] of Object.entries(byIP)) {
    const ts   = evs.map(e=>e.time.getTime()).sort((a,b)=>a-b);
    const peak = maxInWindow(ts, T.sshFailWindow);
    if (peak >= T.sshFailMin || ts.length >= T.sshFailTotal) {
      out.push(mkAlert('BRUTE_FORCE_SSH','HIGH','BRUTE_FORCE',ip,ts.length,
        fts(ts[0]),fts(ts.at(-1)),
        `SSH brute-force: ${ts.length} failed attempts (peak ${peak} in 5 min)`));
    }
  }
  return out;
}

function detectRootLoginAttempts() {
  const out = [];
  // Failed root specifically
  const rootFail = state.parsedData.ssh.filter(e=>e.event==='failed'&&e.user==='root'&&e.ip);
  for (const [ip,evs] of Object.entries(groupBy(rootFail,'ip'))) {
    out.push(mkAlert('ROOT_BRUTE_FORCE','HIGH','BRUTE_FORCE',ip,evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `Root brute-force: ${evs.length} failed password attempt(s) for root account`));
  }
  // Successful root login
  const rootOk = state.parsedData.ssh.filter(e=>(e.event==='accepted'||e.event==='root_login')&&e.user==='root');
  if (rootOk.length) {
    out.push(mkAlert('ROOT_LOGIN_SUCCESS','CRITICAL','BRUTE_FORCE',
      rootOk[0]?.ip||'N/A',rootOk.length,
      rootOk[0]?.time?.toLocaleString(),rootOk.at(-1)?.time?.toLocaleString(),
      `CRITICAL: Successful ROOT login detected! (${rootOk.length} session(s))`));
  }
  return out;
}

function detectSuccessAfterFailures() {
  const out     = [];
  const failIPs = new Set(state.parsedData.ssh.filter(e=>e.event==='failed'||e.event==='invalid').map(e=>e.ip));
  const okByIP  = groupBy(state.parsedData.ssh.filter(e=>e.event==='accepted'&&failIPs.has(e.ip)), 'ip');
  for (const [ip,evs] of Object.entries(okByIP)) {
    const failures = state.parsedData.ssh.filter(e=>e.ip===ip&&(e.event==='failed'||e.event==='invalid')).length;
    if (failures >= 3) {
      out.push(mkAlert('ACCOUNT_COMPROMISE','CRITICAL','BRUTE_FORCE',ip,failures,
        evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
        `Account compromise: ${failures} prior failures then SUCCESSFUL login from ${ip} — possible credential breach`));
    }
  }
  return out;
}

function detectWebBruteForce() {
  const out      = [];
  const LOGIN_RE = /\/(?:login|signin|auth|wp-login\.php|admin\/login|user\/login|account\/login|session|logon|sign-in)/i;
  const hits     = state.parsedData.web.filter(r=>r.ip&&(r.status===401||r.status===403)&&LOGIN_RE.test(r.path||''));
  for (const [ip,reqs] of Object.entries(groupBy(hits,'ip'))) {
    const ts   = reqs.map(r=>r.time?.getTime()||0).sort((a,b)=>a-b);
    const peak = maxInWindow(ts, T.webAuthWindow);
    if (peak >= T.webAuthFailMin) {
      out.push(mkAlert('WEB_BRUTE_FORCE','HIGH','BRUTE_FORCE',ip,ts.length,
        fts(ts[0]),fts(ts.at(-1)),
        `Web login brute-force: ${ts.length} auth failures on login endpoint (peak ${peak}/5 min from ${ip})`));
    }
  }
  return out;
}

function detectCredentialStuffing() {
  const out    = [];
  const failed = state.parsedData.ssh.filter(e=>(e.event==='failed'||e.event==='invalid')&&e.ip&&e.user);
  for (const [ip,evs] of Object.entries(groupBy(failed,'ip'))) {
    const users = new Set(evs.map(e=>e.user));
    if (users.size >= T.credStuffUsers) {
      out.push(mkAlert('CREDENTIAL_STUFFING','HIGH','BRUTE_FORCE',ip,users.size,
        evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
        `Credential stuffing: ${users.size} distinct usernames tried from same IP ${ip}`,
        { users:[...users].slice(0,8) }));
    }
  }
  return out;
}

function detectUnusualHourLogin() {
  const out   = [];
  const ok    = state.parsedData.ssh.filter(e=>e.event==='accepted'&&e.ip);
  const night = ok.filter(e=>{ const h=e.time?.getHours(); return typeof h==='number'&&h>=T.unusualHourStart&&h<T.unusualHourEnd; });
  for (const [ip,evs] of Object.entries(groupBy(night,'ip'))) {
    out.push(mkAlert('ODD_HOUR_LOGIN','MEDIUM','BRUTE_FORCE',ip,evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `Login at unusual hour (midnight–5 AM): ${evs.length} successful SSH session(s) from ${ip}`));
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 2 — RECONNAISSANCE / SCANNING
// ═════════════════════════════════════════════════════════════════════════════

function detect404Flood() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>r.ip&&r.status===404);
  for (const [ip,reqs] of Object.entries(groupBy(hits,'ip'))) {
    if (reqs.length >= T.notFoundMin) {
      const paths = [...new Set(reqs.map(r=>r.path))].slice(0,8);
      out.push(mkAlert('SCANNING_404','MEDIUM','RECONNAISSANCE',ip,reqs.length,
        reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
        `Scanning behaviour: ${reqs.length} HTTP 404 responses from ${ip} — directory/file enumeration likely`,
        { paths }));
    }
  }
  return out;
}

function detectAdminProbing() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>r.ip&&r.path&&ADMIN_PATHS.test(r.path));
  for (const [ip,reqs] of Object.entries(groupBy(hits,'ip'))) {
    if (reqs.length >= T.adminProbeMin) {
      const paths = [...new Set(reqs.map(r=>r.path))].slice(0,8);
      out.push(mkAlert('ADMIN_PROBE','MEDIUM','RECONNAISSANCE',ip,reqs.length,
        reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
        `Admin panel probing: ${reqs.length} requests to privileged paths from ${ip}`,
        { paths }));
    }
  }
  return out;
}

function detectEndpointScan() {
  const out  = [];
  const byIP = groupBy(state.parsedData.web.filter(r=>r.ip),'ip');
  for (const [ip,reqs] of Object.entries(byIP)) {
    const ts    = reqs.map(r=>r.time?.getTime()||0).sort((a,b)=>a-b);
    const first = ts[0];
    const inWin = reqs.filter(r=>r.time?.getTime()-first < 120_000);
    const uniq  = new Set(inWin.map(r=>r.path));
    if (uniq.size >= T.endpointScanMin) {
      out.push(mkAlert('ENDPOINT_SCAN','MEDIUM','RECONNAISSANCE',ip,uniq.size,
        fts(ts[0]),fts(ts.at(-1)),
        `Sequential endpoint scan: ${uniq.size} unique paths hit in <2 minutes from ${ip}`));
    }
  }
  return out;
}

function detectPortScan() {
  const out  = [];
  const blocked = state.parsedData.firewall.filter(f=>f.action==='BLOCK'&&f.srcIP&&f.dstPort);
  for (const [ip,evs] of Object.entries(groupBy(blocked,'srcIP'))) {
    const ports = new Set(evs.map(e=>e.dstPort));
    if (ports.size >= T.portScanMin) {
      const ts = evs.map(e=>e.time?.getTime()||0).sort((a,b)=>a-b);
      out.push(mkAlert('PORT_SCAN','HIGH','RECONNAISSANCE',ip,ports.size,
        fts(ts[0]),fts(ts.at(-1)),
        `Port scan: ${ports.size} distinct blocked destination ports from ${ip}`,
        { ports:[...ports].sort((a,b)=>a-b).slice(0,12) }));
    }
  }
  return out;
}

function detectFirewallRecon() {
  const out     = [];
  const blocked = state.parsedData.firewall.filter(f=>f.action==='BLOCK'&&f.srcIP);
  for (const [ip,evs] of Object.entries(groupBy(blocked,'srcIP'))) {
    const ts = evs.map(e=>e.time?.getTime()||0).sort((a,b)=>a-b);
    // Many blocked packets but few distinct ports → network sweep
    const ports = new Set(evs.map(e=>e.dstPort).filter(Boolean));
    if (evs.length >= 20 && ports.size < T.portScanMin) {
      out.push(mkAlert('NETWORK_SWEEP','MEDIUM','RECONNAISSANCE',ip,evs.length,
        fts(ts[0]),fts(ts.at(-1)),
        `Network sweep: ${evs.length} blocked connection attempts from ${ip}`));
    }
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 3 — DoS / HIGH TRAFFIC
// ═════════════════════════════════════════════════════════════════════════════

function detectHTTPFlood() {
  const out  = [];
  const byIP = groupBy(state.parsedData.web.filter(r=>r.ip),'ip');
  for (const [ip,reqs] of Object.entries(byIP)) {
    const ts   = reqs.map(r=>r.time?.getTime()||0).sort((a,b)=>a-b);
    const peak = maxInWindow(ts, T.httpFloodWindow);
    if (peak >= T.httpFloodMin) {
      out.push(mkAlert('HTTP_FLOOD','HIGH','DOS',ip,peak,
        fts(ts[0]),fts(ts.at(-1)),
        `Possible DoS / HTTP flood: ${peak} requests/min from ${ip} (total ${ts.length} requests)`));
    }
  }
  return out;
}

function detectFirewallFlood() {
  const out  = [];
  const byIP = groupBy(state.parsedData.firewall.filter(f=>f.srcIP&&f.action==='BLOCK'),'srcIP');
  for (const [ip,evs] of Object.entries(byIP)) {
    const ts   = evs.map(e=>e.time?.getTime()||0).sort((a,b)=>a-b);
    const peak = maxInWindow(ts, T.httpFloodWindow);
    if (peak >= T.fwFloodMin) {
      out.push(mkAlert('FIREWALL_FLOOD','HIGH','DOS',ip,peak,
        fts(ts[0]),fts(ts.at(-1)),
        `Firewall flood: ${peak} blocked packets/min from ${ip}`));
    }
  }
  return out;
}

function detectErrorStorm() {
  const out  = [];
  const byIP = groupBy(state.parsedData.web.filter(r=>r.ip),'ip');
  for (const [ip,reqs] of Object.entries(byIP)) {
    const errors = reqs.filter(r=>r.status>=400);
    if (errors.length >= T.errorStormCount && errors.length/reqs.length > T.errorStormRatio) {
      out.push(mkAlert('ERROR_STORM','MEDIUM','DOS',ip,errors.length,
        reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
        `Error storm: ${errors.length} error responses (${Math.round(errors.length/reqs.length*100)}% error rate) from ${ip}`));
    }
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 4 — EXPLOITATION
// ═════════════════════════════════════════════════════════════════════════════

function detectSQLInjection() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>{
    const test = decodeURISafe((r.path||'')+(r.userAgent||'')+(r.referrer||''));
    return SQLI.test(test);
  });
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    out.push(mkAlert('SQL_INJECTION','CRITICAL','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `SQL injection: ${reqs.length} request(s) contain SQLi signatures from ${ip}`,
      { samples:reqs.map(r=>r.path).filter(Boolean).slice(0,4) }));
  }
  // SQLi from unknown IP
  const noIP = hits.filter(r=>!r.ip);
  if (noIP.length) {
    out.push(mkAlert('SQL_INJECTION','CRITICAL','EXPLOITATION','unknown',noIP.length,
      noIP[0]?.time?.toLocaleString(),noIP.at(-1)?.time?.toLocaleString(),
      `SQL injection payloads detected in ${noIP.length} request(s) (no IP recorded)`));
  }
  return out;
}

function detectXSS() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>{
    const test = decodeURISafe((r.path||'')+(r.userAgent||'')+(r.referrer||''));
    return XSS.test(test);
  });
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    out.push(mkAlert('XSS_ATTEMPT','HIGH','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `Cross-site scripting (XSS): ${reqs.length} request(s) with XSS payloads from ${ip}`,
      { samples:reqs.map(r=>r.path).filter(Boolean).slice(0,4) }));
  }
  return out;
}

function detectDirectoryTraversal() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>TRAVERSAL.test(decodeURISafe(r.path||'')));
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    out.push(mkAlert('DIRECTORY_TRAVERSAL','HIGH','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `Directory traversal: ${reqs.length} request(s) with ../../ or /etc/passwd patterns from ${ip}`,
      { samples:reqs.map(r=>r.path).filter(Boolean).slice(0,4) }));
  }
  return out;
}

function detectCommandInjection() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>CMDI.test(decodeURISafe((r.path||'')+(r.userAgent||''))));
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    out.push(mkAlert('COMMAND_INJECTION','CRITICAL','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `Command injection: ${reqs.length} request(s) with shell command patterns from ${ip}`,
      { samples:reqs.map(r=>r.path).filter(Boolean).slice(0,4) }));
  }
  return out;
}

function detectEncodedAttacks() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>ENCODED_ATTACK.test(r.path||''));
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    out.push(mkAlert('ENCODED_ATTACK','HIGH','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `Encoded attack string: ${reqs.length} request(s) with URL-encoded attack payloads from ${ip}`,
      { samples:reqs.map(r=>r.path).filter(Boolean).slice(0,4) }));
  }
  return out;
}

function detectMaliciousUserAgent() {
  const out  = [];
  const hits = state.parsedData.web.filter(r=>r.userAgent&&BAD_AGENTS.test(r.userAgent));
  for (const [ip,reqs] of Object.entries(groupBy(hits.filter(r=>r.ip),'ip'))) {
    const agents = [...new Set(reqs.map(r=>r.userAgent))].slice(0,4);
    out.push(mkAlert('MALICIOUS_USER_AGENT','HIGH','EXPLOITATION',ip,reqs.length,
      reqs[0]?.time?.toLocaleString(),reqs.at(-1)?.time?.toLocaleString(),
      `Attack tool detected: ${reqs.length} request(s) from known-malicious user-agent from ${ip}`,
      { agents }));
  }
  // If no IP available (CLF without agent — flagged separately)
  const noIP = hits.filter(r=>!r.ip);
  if (noIP.length) {
    const agents = [...new Set(noIP.map(r=>r.userAgent))].slice(0,4);
    out.push(mkAlert('MALICIOUS_USER_AGENT','HIGH','EXPLOITATION','N/A',noIP.length,
      noIP[0]?.time?.toLocaleString(),noIP.at(-1)?.time?.toLocaleString(),
      `Attack tool user-agents seen ${noIP.length} time(s)`, { agents }));
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 5 — PRIVILEGE ESCALATION
// ═════════════════════════════════════════════════════════════════════════════

function detectSudoAbuse() {
  const out    = [];
  const fails  = state.parsedData.syslog.filter(e=>e.event==='sudo_fail'&&e.user);
  for (const [user,evs] of Object.entries(groupBy(fails,'user'))) {
    if (evs.length >= T.sudoFailMin) {
      out.push(mkAlert('SUDO_ABUSE','HIGH','PRIVILEGE_ESCALATION','local',evs.length,
        evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
        `sudo authentication failures for user "${user}": ${evs.length} failed attempts`));
    }
  }
  return out;
}

function detectSuspiciousSudoCommand() {
  const out   = [];
  const RISKY = /\b(?:sh|bash|python\d?|perl|ruby|nc|ncat|socat|chmod\s+[0-7]*7|chown\s+root|dd\s|mkfs|wget|curl\s+-[oO]|tee\s+\/|rm\s+-rf)\b|\/etc\/(?:passwd|shadow|sudoers)|>>\s*\/etc/i;
  const cmds  = state.parsedData.syslog.filter(e=>e.event==='sudo_cmd'&&e.cmd&&RISKY.test(e.cmd));
  for (const [user,evs] of Object.entries(groupBy(cmds,'user'))) {
    out.push(mkAlert('SUSPICIOUS_SUDO_CMD','HIGH','PRIVILEGE_ESCALATION','local',evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `High-risk sudo command(s) executed by "${user}"`,
      { cmds:evs.map(e=>e.cmd).slice(0,5) }));
  }
  return out;
}

function detectNewUserCreated() {
  const out  = [];
  const evs  = state.parsedData.syslog.filter(e=>e.event==='new_user'&&e.user);
  if (evs.length) {
    const users = [...new Set(evs.map(e=>e.user))];
    out.push(mkAlert('NEW_USER_CREATED','MEDIUM','PRIVILEGE_ESCALATION','local',evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `New system user account(s) created: ${users.join(', ')}`));
  }
  return out;
}

function detectPasswordChange() {
  const out  = [];
  const evs  = state.parsedData.syslog.filter(e=>e.event==='passwd_chg'&&e.user);
  if (evs.length) {
    const users = [...new Set(evs.map(e=>e.user))];
    out.push(mkAlert('PASSWORD_CHANGED','MEDIUM','PRIVILEGE_ESCALATION','local',evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `Password changed for account(s): ${users.join(', ')}`));
  }
  return out;
}

function detectNewGroup() {
  const out  = [];
  const evs  = state.parsedData.syslog.filter(e=>e.event==='new_group'&&e.user);
  if (evs.length) {
    const groups = [...new Set(evs.map(e=>e.user))];
    out.push(mkAlert('NEW_GROUP_CREATED','LOW','PRIVILEGE_ESCALATION','local',evs.length,
      evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
      `New system group(s) created: ${groups.join(', ')}`));
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// CATEGORY 6 — BLACKLISTED IP
// ═════════════════════════════════════════════════════════════════════════════

function detectBlacklisted() {
  const out    = [];
  const allIPs = new Set([
    ...state.parsedData.web.map(r=>r.ip),
    ...state.parsedData.ssh.map(r=>r.ip),
    ...state.parsedData.firewall.map(r=>r.srcIP),
    ...state.parsedData.apacheErr.map(r=>r.ip),
  ].filter(Boolean));

  for (const ip of allIPs) {
    if (BLACKLIST.has(ip)) {
      const web = state.parsedData.web.filter(r=>r.ip===ip).length;
      const ssh = state.parsedData.ssh.filter(r=>r.ip===ip).length;
      const fw  = state.parsedData.firewall.filter(r=>r.srcIP===ip).length;
      out.push(mkAlert('BLACKLISTED_IP','CRITICAL','BLACKLISTED_IP',ip,web+ssh+fw,
        null,null,
        `Known-malicious IP ${ip}: ${web} web + ${ssh} SSH + ${fw} firewall events detected`));
    }
  }
  return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// ANOMALY — Apache error spikes per IP
// ═════════════════════════════════════════════════════════════════════════════
function detectApacheErrorSpike() {
  const out  = [];
  const byIP = groupBy(state.parsedData.apacheErr.filter(r=>r.ip), 'ip');
  for (const [ip,evs] of Object.entries(byIP)) {
    if (evs.length >= T.apacheErrMin) {
      out.push(mkAlert('APACHE_ERROR_SPIKE','LOW','ANOMALY',ip,evs.length,
        evs[0]?.time?.toLocaleString(),evs.at(-1)?.time?.toLocaleString(),
        `Apache error spike: ${evs.length} error log entries associated with ${ip}`));
    }
  }
  return out;
}

// ─────────────────────────── UTIL ────────────────────────────────────────────
function decodeURISafe(s) {
  try { return decodeURIComponent(s); } catch { return s; }
}

// ─────────────────────────── PUBLIC ENTRY POINT ───────────────────────────────
export function detectThreats() {
  const raw = [
    // Cat 1
    ...detectSSHBruteForce(),
    ...detectRootLoginAttempts(),
    ...detectSuccessAfterFailures(),
    ...detectWebBruteForce(),
    ...detectCredentialStuffing(),
    ...detectUnusualHourLogin(),
    // Cat 2
    ...detect404Flood(),
    ...detectAdminProbing(),
    ...detectEndpointScan(),
    ...detectPortScan(),
    ...detectFirewallRecon(),
    // Cat 3
    ...detectHTTPFlood(),
    ...detectFirewallFlood(),
    ...detectErrorStorm(),
    // Cat 4
    ...detectSQLInjection(),
    ...detectXSS(),
    ...detectDirectoryTraversal(),
    ...detectCommandInjection(),
    ...detectEncodedAttacks(),
    ...detectMaliciousUserAgent(),
    // Cat 5
    ...detectSudoAbuse(),
    ...detectSuspiciousSudoCommand(),
    ...detectNewUserCreated(),
    ...detectPasswordChange(),
    ...detectNewGroup(),
    // Cat 6
    ...detectBlacklisted(),
    // Anomaly
    ...detectApacheErrorSpike(),
  ];

  raw.sort((a,b) => SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity));
  state.allAlerts = raw;
  return raw;
}
