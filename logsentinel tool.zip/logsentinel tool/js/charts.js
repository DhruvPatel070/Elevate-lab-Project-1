/**
 * charts.js — All Chart.js visualizations (5 charts).
 */
import { state, CHART_COLORS, CATEGORIES } from './state.js';

function baseOpts() {
  const {grid:G, text:T} = CHART_COLORS;
  return {
    responsive:true, maintainAspectRatio:false,
    plugins:{ legend:{display:false} },
    scales:{
      x:{ grid:{color:G}, ticks:{color:T,font:{family:'Share Tech Mono',size:10}} },
      y:{ grid:{color:G}, ticks:{color:T,font:{family:'Share Tech Mono',size:10}} },
    },
  };
}

function mk(key, canvasId, config) {
  if (state.charts[key]) { try{ state.charts[key].destroy(); }catch(_){} }
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  state.charts[key] = new Chart(ctx, config);
}

// Chart 1 — Top IPs by event volume
function buildTopIPs() {
  const alerted = new Set(state.allAlerts.map(a=>a.ip));
  const cnt = {};
  [...state.parsedData.web, ...state.parsedData.ssh, ...state.parsedData.firewall,
   ...state.parsedData.apacheErr].forEach(r=>{
    const ip = r.ip||r.srcIP; if(ip){ cnt[ip]=(cnt[ip]||0)+1; }
  });
  const top = Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,10);

  if (top.length) {
    document.getElementById('chart1-title').textContent = '📡 TOP IPs BY EVENT VOLUME';
    mk('topIPs','chart-top-ips',{
      type:'bar',
      data:{
        labels:top.map(([ip])=>ip),
        datasets:[{
          data:top.map(([,c])=>c),
          backgroundColor:top.map(([ip])=>alerted.has(ip)?'rgba(255,59,92,0.75)':'rgba(0,212,255,0.5)'),
          borderColor:top.map(([ip])=>alerted.has(ip)?'#ff3b5c':'#00d4ff'),
          borderWidth:1,borderRadius:4,
        }],
      },
      options:{...baseOpts(),indexAxis:'y',
        plugins:{legend:{display:false},
          tooltip:{callbacks:{label:ctx=>`${ctx.raw.toLocaleString()} events${alerted.has(top[ctx.dataIndex]?.[0])?'  ⚠️ ALERTED':''}`}}
        }
      },
    });
  } else if (state.parsedData.openstack.length) {
    document.getElementById('chart1-title').textContent = '📡 TOP COMPONENTS (OPENSTACK)';
    const cc={};
    state.parsedData.openstack.forEach(e=>{cc[e.component]=(cc[e.component]||0)+1;});
    const topC=Object.entries(cc).sort((a,b)=>b[1]-a[1]).slice(0,8);
    mk('topIPs','chart-top-ips',{type:'bar',
      data:{labels:topC.map(([c])=>c.split('.').slice(-2).join('.')),
            datasets:[{data:topC.map(([,v])=>v),backgroundColor:'rgba(167,139,250,0.5)',borderColor:'#a78bfa',borderWidth:1,borderRadius:4}]},
      options:{...baseOpts(),indexAxis:'y'},
    });
  }
}

// Chart 2 — Activity Timeline (5-min bins)
function buildTimeline() {
  const BIN=300_000;
  const tot={}, threat={};
  const all=[...state.parsedData.web,...state.parsedData.ssh,...state.parsedData.firewall,
             ...state.parsedData.openstack,...state.parsedData.syslog,...state.parsedData.app];
  all.forEach(r=>{
    if(!r.time||isNaN(r.time.getTime())) return;
    const k=new Date(Math.floor(r.time.getTime()/BIN)*BIN).toLocaleTimeString();
    tot[k]=(tot[k]||0)+1;
  });
  // Threat events: SSH fails, web errors, firewall blocks
  [...state.parsedData.ssh.filter(e=>e.event==='failed'||e.event==='invalid'),
   ...state.parsedData.web.filter(r=>r.status>=400),
   ...state.parsedData.firewall.filter(f=>f.action==='BLOCK')].forEach(r=>{
    if(!r.time||isNaN(r.time.getTime())) return;
    const k=new Date(Math.floor(r.time.getTime()/BIN)*BIN).toLocaleTimeString();
    threat[k]=(threat[k]||0)+1;
  });
  const keys=Object.keys(tot).sort();
  const T=CHART_COLORS.text;
  const ds=[
    {data:keys.map(k=>tot[k]),label:'All Events',borderColor:'#00d4ff',backgroundColor:'rgba(0,212,255,0.07)',borderWidth:2,pointRadius:2,tension:0.4,fill:true},
  ];
  if(Object.keys(threat).length)
    ds.push({data:keys.map(k=>threat[k]||0),label:'Threat Events',borderColor:'#ff3b5c',backgroundColor:'rgba(255,59,92,0.05)',borderWidth:1.5,pointRadius:2,tension:0.4,fill:false});
  mk('timeline','chart-timeline',{type:'line',data:{labels:keys,datasets:ds},
    options:{...baseOpts(),plugins:{legend:{display:ds.length>1,labels:{color:T,font:{size:10,family:'Share Tech Mono'},boxWidth:10}}}}});
}

// Chart 3 — HTTP status codes or log level distribution
function buildStatusOrLevel() {
  if(state.parsedData.web.filter(r=>r.status).length){
    document.getElementById('chart3-title').textContent='🔢 HTTP STATUS CODES';
    const sc={};
    state.parsedData.web.forEach(r=>{if(r.status)sc[r.status]=(sc[r.status]||0)+1;});
    const ks=Object.keys(sc).sort();
    mk('status','chart-status',{type:'bar',data:{labels:ks,datasets:[{
      data:ks.map(k=>sc[k]),
      backgroundColor:ks.map(k=>+k<300?'rgba(0,255,136,0.6)':+k<400?'rgba(0,212,255,0.6)':+k<500?'rgba(255,215,0,0.6)':'rgba(255,59,92,0.7)'),
      borderColor:ks.map(k=>+k<300?'#00ff88':+k<400?'#00d4ff':+k<500?'#ffd700':'#ff3b5c'),
      borderWidth:1,borderRadius:4,
    }]},options:baseOpts()});
  } else if (state.parsedData.openstack.length||state.parsedData.app.length) {
    document.getElementById('chart3-title').textContent='🔢 LOG LEVEL DISTRIBUTION';
    const lv={DEBUG:0,INFO:0,WARNING:0,ERROR:0,CRITICAL:0,FATAL:0};
    [...state.parsedData.openstack,...state.parsedData.app].forEach(e=>{if(e.level&&e.level in lv)lv[e.level]++;});
    const ks=Object.keys(lv).filter(k=>lv[k]);
    const lc=CHART_COLORS.level;
    mk('status','chart-status',{type:'bar',data:{labels:ks,datasets:[{
      data:ks.map(k=>lv[k]),backgroundColor:ks.map(k=>lc[k]||'rgba(0,212,255,0.5)'),
      borderColor:ks.map(k=>(lc[k]||'#00d4ff').replace(/0\.[0-9]/,'1')),borderWidth:1,borderRadius:4,
    }]},options:baseOpts()});
  } else if (state.parsedData.firewall.length) {
    document.getElementById('chart3-title').textContent='🔢 FIREWALL ACTIONS';
    const ac={ALLOW:0,BLOCK:0};
    state.parsedData.firewall.forEach(f=>{if(f.action in ac)ac[f.action]++;});
    mk('status','chart-status',{type:'bar',data:{labels:Object.keys(ac),datasets:[{
      data:Object.values(ac),backgroundColor:['rgba(0,255,136,0.6)','rgba(255,59,92,0.6)'],
      borderColor:['#00ff88','#ff3b5c'],borderWidth:1,borderRadius:4,
    }]},options:baseOpts()});
  }
}

// Chart 4 — Alert categories doughnut
function buildCategories() {
  const cc={};
  state.allAlerts.forEach(a=>{cc[a.category]=(cc[a.category]||0)+1;});
  const ks=Object.keys(cc);
  if(!ks.length) return;
  const labels=ks.map(k=>CATEGORIES[k]?.short||k);
  const colors=ks.map(k=>CATEGORIES[k]?.color||'#00d4ff');
  mk('cats','chart-categories',{type:'doughnut',
    data:{labels,datasets:[{data:ks.map(k=>cc[k]),backgroundColor:colors.map(c=>c+'88'),borderColor:colors,borderWidth:2}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:true,position:'bottom',
      labels:{color:CHART_COLORS.text,font:{size:10,family:'Share Tech Mono'},boxWidth:10,padding:8}}}}});
}

// Chart 5 — Severity breakdown doughnut
function buildSeverity() {
  const sc={CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0};
  state.allAlerts.forEach(a=>{if(a.severity in sc)sc[a.severity]++;});
  const ks=Object.keys(sc).filter(k=>sc[k]);
  if(!ks.length) return;
  const colors=ks.map(k=>CHART_COLORS.sev[k]||'#00d4ff');
  mk('sev','chart-severity',{type:'doughnut',
    data:{labels:ks,datasets:[{data:ks.map(k=>sc[k]),backgroundColor:colors.map(c=>c+'88'),borderColor:colors,borderWidth:2}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:true,position:'bottom',
      labels:{color:CHART_COLORS.text,font:{size:10,family:'Share Tech Mono'},boxWidth:10,padding:8}}}}});
}

export function renderCharts() {
  buildTopIPs();
  buildTimeline();
  buildStatusOrLevel();
  buildCategories();
  buildSeverity();
}
