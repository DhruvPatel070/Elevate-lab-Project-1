/**
 * parser.js
 * Auto-detects and parses 7 log formats into structured objects.
 *
 * Formats:
 *  1. Apache / Nginx CLF (Common Log Format)       → web
 *  2. Apache / Nginx Combined Log Format           → web
 *  3. Apache Error Log                             → apacheErr
 *  4. SSH Authentication Log (auth.log)            → ssh
 *  5. System Log / syslog (auth + privilege)       → syslog
 *  6. Firewall Log (UFW / iptables / generic deny) → firewall
 *  7. Application Log (timestamp + level + msg)   → app
 *  8. OpenStack Nova Log                           → openstack
 *
 * Every entry carries at minimum: { time:Date, raw:string }
 * Web entries carry:  { ip, time, method, path, status, size, userAgent, referrer }
 * SSH entries carry:  { ip, time, event, user }
 * Firewall entries:   { srcIP, dstIP, dstPort, proto, action, time }
 * Syslog entries:     { time, host, process, pid, msg, event, user, ip, isPrivilege }
 */

import { state } from './state.js';

// ──────────────────────────── REGEX PATTERNS ─────────────────────────────────

// Month name → index
const MON = { Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11 };

// 1. CLF:      IP ident user [DD/Mon/YYYY:HH:MM:SS tz] "METHOD /path HTTP/x" STATUS SIZE
export const R_CLF = /^(\d{1,3}(?:\.\d{1,3}){3})\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"([A-Z]+)\s+(\S+)\s+[^"]+"\s+(\d{3})\s+(\S+)/;

// 2. Combined: CLF + "referrer" "user-agent"
export const R_COMBINED = /^(\d{1,3}(?:\.\d{1,3}){3})\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"([A-Z]+)\s+(\S+)\s+[^"]+"\s+(\d{3})\s+(\S+)\s+"([^"]*)"\s+"([^"]*)"/;

// 3. Apache Error:  [DayOfWeek Mon DD HH:MM:SS.µs YYYY] [module:level] [pid N] [client IP:port] msg
//    Also handles:  [YYYY-MM-DD HH:MM:SS] [module:level] ...
export const R_APACHE_ERR_V2 = /^\[([^\]]+)\]\s+\[([^:]+):(\w+)\]\s+(?:\[pid \d+\]\s+)?(?:\[client ([^\]]+)\]\s+)?(.*)/;
export const R_APACHE_ERR_V1 = /^\[(\w{3} \w{3} \d{2} [\d:.]+ \d{4})\]\s+\[(\w+)\]\s+(?:\[client ([^\]]+)\]\s+)?(.*)/;

// 4. SSH - failed password: Mon DD HH:MM:SS host sshd[pid]: Failed password for <user> from <IP>
export const R_SSH_FAIL    = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+Failed password for (?:invalid user )?(\S+) from (\d{1,3}(?:\.\d{1,3}){3})/;
// 4b. SSH - failed pubkey
export const R_SSH_FAILKEY = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+Failed publickey for (\S+) from (\d{1,3}(?:\.\d{1,3}){3})/;
// 4c. SSH - accepted
export const R_SSH_ACCEPT  = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+Accepted (?:password|publickey|keyboard-interactive) for (\S+) from (\d{1,3}(?:\.\d{1,3}){3})/;
// 4d. SSH - invalid user
export const R_SSH_INVALID = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+Invalid user (\S+) from (\d{1,3}(?:\.\d{1,3}){3})/;
// 4e. SSH - root login
export const R_SSH_ROOT    = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+ROOT LOGIN/;
// 4f. SSH - connection closed / disconnected
export const R_SSH_CLOSED  = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+(?:Connection closed|Disconnected) (?:from|by)(?: invalid user (\S+))? (\d{1,3}(?:\.\d{1,3}){3})/;
// 4g. SSH - too many auth failures
export const R_SSH_TOOMANY = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+\S+:\s+error: maximum authentication attempts exceeded for (\S+) from (\d{1,3}(?:\.\d{1,3}){3})/;

// 5a. sudo failure
export const R_SUDO_FAIL  = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+sudo(?:\[\d+\])?:\s+(?:pam_unix.*authentication failure|(\S+)\s*:.*authentication failure).*user=(\S+)/i;
// 5b. sudo command (success)
export const R_SUDO_CMD   = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+\S+\s+sudo(?:\[\d+\])?:\s+(\S+)\s+:.*COMMAND=(.*)/;
// 5c. new user created
export const R_NEW_USER   = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*(?:useradd|adduser|new user).*[;\s]name=(\S+)/i;
// 5d. password changed
export const R_PASSWD_CHG = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*(?:passwd|chpasswd).*changed password for (\S+)/i;
// 5e. new group
export const R_NEW_GROUP  = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*(?:groupadd|new group).*[;\s]name=(\S+)/i;

// 6a. UFW: Mon DD HH:MM:SS host kernel: [x.y] [UFW BLOCK] ... SRC=IP DST=IP ... PROTO=x DPT=port
export const R_UFW = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*UFW\s+(BLOCK|ALLOW|AUDIT)\s+IN.*SRC=(\d{1,3}(?:\.\d{1,3}){3})\s+DST=(\d{1,3}(?:\.\d{1,3}){3}).*(?:PROTO=(\S+))?.*(?:DPT=(\d+))?/;
// 6b. iptables: ... SRC=IP DST=IP ... PROTO=x DPT=port
export const R_IPTA = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*(?:IN=\S*\s+OUT=)?.*SRC=(\d{1,3}(?:\.\d{1,3}){3})\s+DST=(\d{1,3}(?:\.\d{1,3}){3}).*(?:PROTO=(\S+))?.*(?:DPT=(\d+))?/;
// 6c. Generic deny: ... DENY/BLOCKED/DROPPED from IP
export const R_FW_DENY = /^(\w{3}\s+\d{1,2}\s+[\d:]+).*(?:DENY|BLOCKED|DROPPED|Blocked|denied)\s+.*from\s+(\d{1,3}(?:\.\d{1,3}){3})(?::(\d+))?/i;
// 6d. Cisco/generic: denied by access-list
export const R_FW_CISCO = /(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}).*denied.*(\d{1,3}(?:\.\d{1,3}){3})\s+to\s+(\d{1,3}(?:\.\d{1,3}){3})/i;

// 7. Application log: YYYY-MM-DD HH:MM:SS[.ms] [LEVEL] message
//    or ISO:          2024-01-15T08:23:12Z INFO  message
export const R_APP = /^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+(?:\[?(DEBUG|INFO|WARN(?:ING)?|ERROR|CRITICAL|FATAL|TRACE)\]?)\s+(.*)/i;

// 8. OpenStack Nova: source YYYY-MM-DD HH:MM:SS.ms PID LEVEL component [req-…] message
export const R_OSTACK = /^(\S+)\s+(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+)\s+(\d+)\s+(INFO|WARNING|ERROR|CRITICAL|DEBUG|AUDIT)\s+(\S+)\s+\[([^\]]+)\]\s+(.*)/;
const R_OSTACK_HTTP   = /(\d{1,3}(?:\.\d{1,3}){3})(?:,\S+)?\s+"([A-Z]+)\s+(\S+)[^"]*"\s+status:\s+(\d+)/;

// Generic syslog fallback: Mon DD HH:MM:SS hostname process[pid]: msg
export const R_SYSLOG = /^(\w{3}\s+\d{1,2}\s+[\d:]+)\s+(\S+)\s+(\S+?)(?:\[(\d+)\])?:\s+(.*)/;

// ──────────────────────────── TIME PARSERS ────────────────────────────────────

/** Apache CLF/Combined timestamp: 22/Feb/2024:08:01:12 +0000 */
export function parseWebTime(s) {
  try {
    // Split "22/Feb/2024:08:01:12 +0000" — first colon is after YYYY
    const m = /(\d{2})\/(\w{3})\/(\d{4}):(\d{2}):(\d{2}):(\d{2})/.exec(s);
    if (m) return new Date(+m[3], MON[m[2]], +m[1], +m[4], +m[5], +m[6]);
  } catch (_) {}
  return new Date();
}

/** Syslog timestamp: "Jun  5 09:30:01" — assumes current year */
export function parseSyslogTime(s) {
  try { return new Date(`${new Date().getFullYear()} ${s.trim()}`); }
  catch (_) { return new Date(); }
}

/** ISO / Apache error timestamp (flexible) */
export function parseGenericTime(s) {
  try { return new Date(s); } catch (_) { return new Date(); }
}

// ──────────────────────────── PER-LINE DISPATCHER ────────────────────────────

function parseLine(line) {
  let m;

  // ── 8. OpenStack (very specific prefix — check before syslog) ──────────────
  m = R_OSTACK.exec(line);
  if (m) {
    state.detectedFormats.add('OpenStack Nova');
    const entry = {
      source: m[1], time: new Date(m[2]), pid: m[3], level: m[4],
      component: m[5], msg: m[7], raw: line,
      instance: (/\[instance: ([a-f0-9-]+)\]/.exec(m[7]) || [])[1] || null,
    };
    const h = R_OSTACK_HTTP.exec(m[7]);
    if (h) {
      Object.assign(entry, { ip:h[1], method:h[2], path:h[3], status:+h[4] });
      state.parsedData.web.push({ ...entry });
      state.stats.webRequests++;
    }
    state.parsedData.openstack.push(entry);
    state.stats.ostackEvents++;
    return;
  }

  // ── 2. Combined log (superset of CLF — try first) ─────────────────────────
  m = R_COMBINED.exec(line);
  if (m) {
    state.detectedFormats.add('Apache/Nginx Access Log');
    state.parsedData.web.push({
      ip: m[1], time: parseWebTime(m[2]), method: m[3],
      path: m[4], status: +m[5], size: m[6] === '-' ? 0 : +m[6],
      referrer: m[7] !== '-' ? m[7] : '', userAgent: m[8], raw: line,
    });
    state.stats.webRequests++;
    return;
  }

  // ── 1. CLF ─────────────────────────────────────────────────────────────────
  m = R_CLF.exec(line);
  if (m) {
    state.detectedFormats.add('Apache/Nginx Access Log');
    state.parsedData.web.push({
      ip: m[1], time: parseWebTime(m[2]), method: m[3],
      path: m[4], status: +m[5], size: m[6] === '-' ? 0 : +m[6],
      referrer: '', userAgent: '', raw: line,
    });
    state.stats.webRequests++;
    return;
  }

  // ── 3. Apache Error Log ────────────────────────────────────────────────────
  m = R_APACHE_ERR_V2.exec(line) || R_APACHE_ERR_V1.exec(line);
  if (m && (line.includes('[error]') || line.includes('[warn') || line.includes('[crit') || line.includes('[emerg') || line.includes('[alert') || line.includes(':error]') || line.includes(':warn]'))) {
    state.detectedFormats.add('Apache Error Log');
    const clientRaw = m[4] || m[3] || '';
    const ip = (/(\d{1,3}(?:\.\d{1,3}){3})/.exec(clientRaw) || [])[1] || null;
    state.parsedData.apacheErr.push({
      time: parseGenericTime(m[1]), level: m[3] || m[2], ip,
      msg: m[5] || m[4] || '', raw: line,
    });
    state.stats.apacheErrors++;
    return;
  }

  // ── 4. SSH — ordered from most-specific to least ───────────────────────────
  const sshMap = [
    [R_SSH_TOOMANY, (x) => ({ event:'toomany',  user:x[2], ip:x[3] })],
    [R_SSH_FAILKEY, (x) => ({ event:'failed',   user:x[2], ip:x[3] })],
    [R_SSH_FAIL,    (x) => ({ event:'failed',   user:x[2], ip:x[3] })],
    [R_SSH_ACCEPT,  (x) => ({ event:'accepted', user:x[2], ip:x[3] })],
    [R_SSH_INVALID, (x) => ({ event:'invalid',  user:x[2], ip:x[3] })],
    [R_SSH_ROOT,    ()  => ({ event:'root_login',user:'root',ip:null })],
    [R_SSH_CLOSED,  (x) => ({ event:'closed',   user:x[2]||null, ip:x[3] })],
  ];
  for (const [rx, build] of sshMap) {
    m = rx.exec(line);
    if (m) {
      state.detectedFormats.add('SSH Auth Log');
      state.parsedData.ssh.push({ time: parseSyslogTime(m[1]), ...build(m), raw: line });
      state.stats.sshEvents++;
      return;
    }
  }

  // ── 5. Privilege escalation events (before generic syslog) ────────────────
  const privMap = [
    [R_SUDO_FAIL,  (x) => ({ event:'sudo_fail',  user:x[3]||x[2] })],
    [R_SUDO_CMD,   (x) => ({ event:'sudo_cmd',   user:x[2], cmd:x[3].trim() })],
    [R_NEW_USER,   (x) => ({ event:'new_user',   user:x[2] })],
    [R_PASSWD_CHG, (x) => ({ event:'passwd_chg', user:x[2] })],
    [R_NEW_GROUP,  (x) => ({ event:'new_group',  user:x[2] })],
  ];
  for (const [rx, build] of privMap) {
    m = rx.exec(line);
    if (m) {
      state.detectedFormats.add('System Log');
      state.parsedData.syslog.push({ time:parseSyslogTime(m[1]), ip:null, isPrivilege:true, ...build(m), raw:line });
      state.stats.syslogEvents++;
      return;
    }
  }

  // ── 6. Firewall logs ───────────────────────────────────────────────────────
  m = R_UFW.exec(line);
  if (m) {
    state.detectedFormats.add('Firewall Log');
    state.parsedData.firewall.push({
      time:parseSyslogTime(m[1]), action:m[2]==='BLOCK'?'BLOCK':'ALLOW',
      srcIP:m[3], dstIP:m[4], proto:m[5]||null, dstPort:m[6]?+m[6]:null, raw:line,
    });
    state.stats.firewallEvents++;
    return;
  }
  m = R_FW_DENY.exec(line);
  if (m) {
    state.detectedFormats.add('Firewall Log');
    state.parsedData.firewall.push({
      time:parseSyslogTime(m[1]), action:'BLOCK',
      srcIP:m[2], dstPort:m[3]?+m[3]:null, raw:line,
    });
    state.stats.firewallEvents++;
    return;
  }
  // iptables kernel log — only if it has SRC= DST= markers
  if (line.includes('SRC=') && line.includes('DST=')) {
    m = R_IPTA.exec(line);
    if (m) {
      state.detectedFormats.add('Firewall Log');
      const action = /ACCEPT/i.test(line) ? 'ALLOW' : 'BLOCK';
      state.parsedData.firewall.push({
        time:parseSyslogTime(m[1]), action,
        srcIP:m[2], dstIP:m[3], proto:m[4]||null, dstPort:m[5]?+m[5]:null, raw:line,
      });
      state.stats.firewallEvents++;
      return;
    }
  }
  m = R_FW_CISCO.exec(line);
  if (m) {
    state.detectedFormats.add('Firewall Log');
    state.parsedData.firewall.push({
      time:parseGenericTime(m[1]), action:'BLOCK', srcIP:m[2], dstIP:m[3], raw:line,
    });
    state.stats.firewallEvents++;
    return;
  }

  // ── 7. Application log ─────────────────────────────────────────────────────
  m = R_APP.exec(line);
  if (m) {
    state.detectedFormats.add('Application Log');
    state.parsedData.app.push({
      time:parseGenericTime(m[1]), level:m[2].toUpperCase(), msg:m[3], raw:line,
    });
    state.stats.appEvents++;
    return;
  }

  // ── Generic syslog fallback ────────────────────────────────────────────────
  m = R_SYSLOG.exec(line);
  if (m) {
    state.detectedFormats.add('System Log');
    state.parsedData.syslog.push({
      time:parseSyslogTime(m[1]), host:m[2], process:m[3],
      pid:m[4]||null, msg:m[5], event:'generic', ip:null, raw:line,
    });
    state.stats.syslogEvents++;
    return;
  }

  state.parsedData.raw.push(line);
}

// ──────────────────────────── PUBLIC API ─────────────────────────────────────

/** Parse a File object and push entries into shared state. */
export async function parseFile(file) {
  const text  = await file.text();
  const lines = text.split(/\r?\n/);
  for (const line of lines) {
    if (!line.trim()) continue;
    state.allLines.push(line);
    parseLine(line);
  }
  state.stats.totalLines = state.allLines.length;
  // Compute unique IPs across all sources
  const ipSet = new Set([
    ...state.parsedData.web.map(r=>r.ip),
    ...state.parsedData.ssh.map(r=>r.ip),
    ...state.parsedData.firewall.map(r=>r.srcIP),
    ...state.parsedData.apacheErr.map(r=>r.ip),
  ].filter(Boolean));
  state.stats.uniqueIPs      = ipSet.size;
  state.stats.totalEntries   = Object.values(state.parsedData)
    .reduce((s,a)=>s+a.length,0) - state.parsedData.raw.length;
}

/** Group array by key string or key function. */
export function groupBy(arr, key) {
  const fn = typeof key==='function' ? key : item => item[key];
  return arr.reduce((acc,item) => { (acc[fn(item)]??=[]).push(item); return acc; }, {});
}
