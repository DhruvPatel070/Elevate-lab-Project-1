/**
 * main.js — Entry point. Wires DOM events to module functions.
 */
import {
  addFiles, renderFileList, analyzeAll,
  filterAlerts, filterByCat, renderAlerts,
  filterLogs, exportJSON, exportCSV, exportHTML, resetTool,
} from './ui.js';
import { state } from './state.js';

// Expose to HTML onclick / inline handlers
window.analyzeAll   = analyzeAll;
window.filterAlerts = filterAlerts;
window.filterByCat  = filterByCat;
window.renderAlerts = renderAlerts;
window.filterLogs   = filterLogs;
window.exportJSON   = exportJSON;
window.exportCSV    = exportCSV;
window.exportHTML   = exportHTML;
window.resetTool    = resetTool;
window.removeFile   = i => { state.allFiles.splice(i,1); renderFileList(); };

const zone  = document.getElementById('upload-zone');
const input = document.getElementById('file-input');

zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('drag-over'); });
zone.addEventListener('dragleave', ()=> zone.classList.remove('drag-over'));
zone.addEventListener('drop', e => { e.preventDefault(); zone.classList.remove('drag-over'); addFiles([...e.dataTransfer.files]); });
zone.addEventListener('click', () => input.click());
input.addEventListener('change', () => addFiles([...input.files]));

document.getElementById('search-box')?.addEventListener('input', renderAlerts);
document.getElementById('log-search')?.addEventListener('input', filterLogs);
