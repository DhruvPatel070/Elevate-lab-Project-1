/**
 * ui.js — All DOM rendering and UI interactions.
 */
import { state, resetState, CATEGORIES, CHART_COLORS } from './state.js';
import { parseFile, R_OSTACK }                          from './parser.js';
import { detectThreats }                                from './detector.js';
import { renderCharts }                                 from './charts.js';

export const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Progress ──────────────────────────────────────────────────────────────────
function setProgress(pct, label) {
  document.getElementById('progress-bar').style.width   = pct + '%';
  document.getElementById('progress-label').textContent = label;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
export function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 4000);
}

// ── File helpers ──────────────────────────────────────────────────────────────
function icon(n) {
  if (/auth|ssh|secure/i.test(n))             return '🔐';
  if (/apache|access|nginx/i.test(n))         return '🌐';
  if (/error/i.test(n))                       return '⚠️';
  if (/firewall|ufw|iptables|pf\.log/i.test(n)) return '🔥';
  if (/nova|openstack/i.test(n))              return '☁️';
  if (/syslog|system|kern/i.test(n))          return '🖥️';
  if (/app|service|daemon/i.test(n))          return '📱';
  return '📄';
}
function fmtSize(b) {
  if (b<1024) return b+' B'; if (b<1048576) return (b/1024).toFixed(1)+' KB'; return (b/1048576).toFixed(1)+' MB';
}

export function renderFileList() {
  document.getElementById('file-list').innerHTML = state.allFiles.map((f,i) => `
    <div class="file-item">
      <span class="file-icon">${icon(f.name)}</span>
      <span class="file-name">${f.name}</span>
      <span class="file-size">${fmtSize(f.size)}</span>
      <button class="file-remove" onclick="window.removeFile(${i})">✕</button>
    </div>`).join('');
  document.getElementById('analyze-btn').disabled = state.allFiles.length === 0;
}

export function addFiles(files) {
  files.forEach(f => { if(!state.allFiles.find(x=>x.name===f.name&&x.size===f.size)) state.allFiles.push(f); });
  renderFileList();
}

// ── Main analysis pipeline ────────────────────────────────────────────────────
export async function analyzeAll() {
  if (!state.allFiles.length) return;
  document.getElementById('progress-zone').style.display = 'block';
  document.getElementById('analyze-btn').disabled = true;
  setProgress(5, 'Reading files…');

  for (let i=0; i<state.allFiles.length; i++) {
    setProgress(10+(i/state.allFiles.length)*45, `Parsing ${state.allFiles[i].name}…`);
    await parseFile(state.allFiles[i]);
    await sleep(20);
  }

  setProgress(60, 'Detecting threats…'); await sleep(60);
  detectThreats();

  setProgress(78, 'Rendering dashboard…'); await sleep(30);
  document.getElementById('upload-section').style.display = 'none';
  document.getElementById('dashboard').style.display      = 'block';
  document.getElementById('format-tag').textContent       = [...state.detectedFormats].join(' · ');

  setProgress(88, 'Building charts…'); await sleep(30);
  renderStats();
  renderCharts();
  buildCategoryFilterBar();
  renderAlerts();
  renderLogViewer();
  setProgress(100, 'Analysis complete');
  showToast(`✅ ${state.allAlerts.length} alerts · ${state.allLines.length.toLocaleString()} log lines parsed`);
}

// ── Stat cards ────────────────────────────────────────────────────────────────
export function renderStats() {
  const n = sev => state.allAlerts.filter(a=>a.severity===sev).length;
  const s = state.stats;
  const totalEntries = s.webRequests+s.sshEvents+s.firewallEvents+s.syslogEvents+s.appEvents+s.apacheErrors+s.ostackEvents;

  let html = `
    <div class="stat-card critical"><div class="stat-num">${n('CRITICAL')}</div><div class="stat-label">Critical</div></div>
    <div class="stat-card high">   <div class="stat-num">${n('HIGH')}</div>    <div class="stat-label">High</div></div>
    <div class="stat-card medium"> <div class="stat-num">${n('MEDIUM')}</div>  <div class="stat-label">Medium</div></div>
    <div class="stat-card info">   <div class="stat-num">${state.allAlerts.length}</div><div class="stat-label">Total Alerts</div></div>
    <div class="stat-card good">   <div class="stat-num">${totalEntries.toLocaleString()}</div><div class="stat-label">Log Entries</div></div>
    <div class="stat-card info">   <div class="stat-num">${s.uniqueIPs}</div>  <div class="stat-label">Unique IPs</div></div>`;
  if (s.webRequests)      html+=`<div class="stat-card info"><div class="stat-num">${s.webRequests.toLocaleString()}</div><div class="stat-label">Web Reqs</div></div>`;
  if (s.sshEvents)        html+=`<div class="stat-card warn"><div class="stat-num">${s.sshEvents.toLocaleString()}</div><div class="stat-label">SSH Events</div></div>`;
  if (s.firewallEvents)   html+=`<div class="stat-card warn"><div class="stat-num">${s.firewallEvents.toLocaleString()}</div><div class="stat-label">FW Events</div></div>`;
  if (s.apacheErrors)     html+=`<div class="stat-card medium"><div class="stat-num">${s.apacheErrors.toLocaleString()}</div><div class="stat-label">Apache Errors</div></div>`;
  document.getElementById('stat-grid').innerHTML = html;
}

// ── Category filter bar ───────────────────────────────────────────────────────
function buildCategoryFilterBar() {
  const used = [...new Set(state.allAlerts.map(a=>a.category))];
  const bar  = document.getElementById('cat-filter-bar');
  bar.innerHTML = '<button class="filter-btn cat-btn active" data-cat="ALL" onclick="window.filterByCat(\'ALL\',this)">ALL CATEGORIES</button>';
  used.forEach(cat => {
    const info = CATEGORIES[cat]||{label:cat,color:'#00d4ff'};
    const count= state.allAlerts.filter(a=>a.category===cat).length;
    const btn  = document.createElement('button');
    btn.className='filter-btn cat-btn';
    btn.dataset.cat=cat;
    btn.style.setProperty('--cc', info.color);
    btn.textContent=`${info.label}  ${count}`;
    btn.onclick=()=>window.filterByCat(cat,btn);
    bar.appendChild(btn);
  });
}

// ── Alerts table ──────────────────────────────────────────────────────────────
export function filterAlerts(sev, btn) {
  state.activeFilter = sev;
  document.querySelectorAll('.sev-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); renderAlerts();
}
export function filterByCat(cat, btn) {
  state.activeCatFilter = cat;
  document.querySelectorAll('.cat-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); renderAlerts();
}

export function renderAlerts() {
  const q  = (document.getElementById('search-box')?.value||'').toLowerCase();
  const ok = state.allAlerts.filter(a => {
    if (state.activeFilter    !=='ALL' && a.severity !==state.activeFilter)    return false;
    if (state.activeCatFilter !=='ALL' && a.category !==state.activeCatFilter) return false;
    if (q && !JSON.stringify(a).toLowerCase().includes(q))                      return false;
    return true;
  });

  const c = document.getElementById('alerts-container');
  if (!ok.length) { c.innerHTML='<div class="empty-state"><span class="big">🔍</span><br>No alerts match the current filters</div>'; return; }

  const SC = CHART_COLORS.sev;
  c.innerHTML=`
    <div class="result-meta">Showing <strong>${ok.length}</strong> of <strong>${state.allAlerts.length}</strong> alerts</div>
    <table class="alerts-table">
      <thead><tr>
        <th>Severity</th><th>Category</th><th>Type</th>
        <th>IP / Source</th><th>Description</th><th>#</th><th>First Seen</th><th>Last Seen</th>
      </tr></thead>
      <tbody>${ok.map(a=>{
        const cat=CATEGORIES[a.category]||{label:a.category,color:'#00d4ff'};
        const extras=a.paths||a.samples||a.agents||a.users||a.cmds||a.ports;
        return `<tr>
          <td><span class="sev-badge sev-${a.severity}">${a.severity}</span></td>
          <td><span class="cat-badge" style="color:${cat.color};border-color:${cat.color}">${cat.label}</span></td>
          <td><code class="type-code">${a.type}</code></td>
          <td><span class="ip-tag">${a.ip}</span></td>
          <td class="desc-cell">${a.description}
            ${extras?`<div class="extra-pill-row">${extras.slice(0,5).map(v=>`<span class="extra-pill">${esc(String(v))}</span>`).join('')}</div>`:''}</td>
          <td class="mono-dim">${a.count??'—'}</td>
          <td class="mono-dim small">${a.first??'—'}</td>
          <td class="mono-dim small">${a.last??'—'}</td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;
}

// ── Log viewer ────────────────────────────────────────────────────────────────
export function renderLogViewer() {
  document.getElementById('log-count').textContent=`${state.allLines.length.toLocaleString()} lines`;
  filterLogs();
}
export function filterLogs() {
  const q     = (document.getElementById('log-search')?.value||'').toLowerCase();
  const lines = q ? state.allLines.filter(l=>l.toLowerCase().includes(q)) : state.allLines;
  document.getElementById('log-count').textContent=`${lines.length.toLocaleString()} / ${state.allLines.length.toLocaleString()} lines`;
  document.getElementById('log-output').innerHTML=
    lines.slice(0,2000).map(line=>{
      let cls='ll-dim';
      if(/\bERROR\b|\bCRITICAL\b|FATAL|Failed password|Invalid user|DROP|BLOCK|injection|traversal|<script/i.test(line)) cls='ll-error';
      else if(/\bWARNING\b|\bWARN\b|sudo.*failure|authentication failure|denied/i.test(line))                           cls='ll-warn';
      else if(/Accepted password|HTTP\/\d[^"]*" 200|spawned successfully/i.test(line))                                  cls='ll-ok';
      else if(R_OSTACK.test(line))                                                                                       cls='ll-openstack';
      else if(/\d+\.\d+\.\d+\.\d+/.test(line))                                                                         cls='ll-ip';
      return `<div class="log-line ${cls}">${esc(line)}</div>`;
    }).join('')+(lines.length>2000?`<div class="ll-dim log-more">…${(lines.length-2000).toLocaleString()} more lines — refine filter to see them</div>`:'');
}

const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// ── Exports ───────────────────────────────────────────────────────────────────
function dl(name,content,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;a.click();}

export function exportJSON() {
  dl('logsentinel_alerts.json', JSON.stringify({
    generated:new Date().toISOString(), formats:[...state.detectedFormats],
    stats:state.stats, total_alerts:state.allAlerts.length, alerts:state.allAlerts,
  },null,2),'application/json');
  showToast('📥 alerts.json downloaded');
}

export function exportCSV() {
  const cols=['severity','category','type','ip','description','count','first','last'];
  const rows=[cols.join(','),...state.allAlerts.map(a=>cols.map(c=>`"${(a[c]??'').toString().replace(/"/g,'""')}"`).join(','))];
  dl('logsentinel_alerts.csv',rows.join('\n'),'text/csv');
  showToast('📊 alerts.csv downloaded');
}

export function exportHTML() {
  const SC=CHART_COLORS.sev;
  const catCounts={};
  state.allAlerts.forEach(a=>{catCounts[a.category]=(catCounts[a.category]||0)+1;});
  const summaryCards=Object.entries(catCounts).map(([k,v])=>{
    const c=CATEGORIES[k]||{label:k,color:'#00d4ff'};
    return `<div style="background:#0a1520;border:1px solid ${c.color};border-radius:8px;padding:12px 18px;min-width:140px;text-align:center">
      <div style="font-size:28px;font-weight:700;color:${c.color};font-family:monospace">${v}</div>
      <div style="font-size:11px;color:#4a7a9b;margin-top:4px">${c.label}</div></div>`;
  }).join('');
  const rows=state.allAlerts.map(a=>{
    const cat=CATEGORIES[a.category]||{label:a.category,color:'#00d4ff'};
    return `<tr>
      <td><span style="background:${SC[a.severity]??'#fff'}22;color:${SC[a.severity]??'#fff'};border:1px solid ${SC[a.severity]??'#fff'};padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700">${a.severity}</span></td>
      <td style="color:${cat.color};font-size:11px">${cat.label}</td>
      <td style="font-family:monospace;font-size:11px">${a.type}</td>
      <td><code style="background:#0a1520;padding:2px 6px;border-radius:3px">${a.ip}</code></td>
      <td>${a.description}</td><td>${a.count??'—'}</td><td>${a.first??'—'}</td><td>${a.last??'—'}</td>
    </tr>`;
  }).join('');
  dl('logsentinel_report.html',`<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>LogSentinel — Incident Report</title>
<style>*{box-sizing:border-box}body{background:#050a0f;color:#c8e6ff;font-family:'Segoe UI',sans-serif;padding:32px;line-height:1.6;margin:0}
h1{color:#00d4ff;margin-bottom:4px}h2{color:#4a7a9b;font-size:13px;letter-spacing:3px;text-transform:uppercase;margin:28px 0 14px;border-bottom:1px solid #1a3a5c;padding-bottom:8px}
.meta{color:#4a7a9b;margin-bottom:24px;font-size:13px}.summary{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:28px}
table{width:100%;border-collapse:collapse;font-size:12px}th{background:#0a1520;padding:10px;text-align:left;color:#4a7a9b;border-bottom:1px solid #1a3a5c;font-size:11px;letter-spacing:1px;text-transform:uppercase}
td{padding:10px;border-bottom:1px solid #0f1f30;vertical-align:top}tr:hover td{background:rgba(0,212,255,.02)}
footer{margin-top:40px;color:#4a7a9b;font-size:11px;border-top:1px solid #1a3a5c;padding-top:12px;text-align:center}</style></head>
<body><h1>🛡️ LogSentinel — Incident Report</h1>
<div class="meta">Generated: ${new Date().toLocaleString()} &nbsp;|&nbsp; Log formats: ${[...state.detectedFormats].join(', ')} &nbsp;|&nbsp; ${state.allAlerts.length} total alerts &nbsp;|&nbsp; ${state.allLines.length.toLocaleString()} lines analyzed</div>
<h2>Attack Summary by Category</h2><div class="summary">${summaryCards}</div>
<h2>Alert Details</h2>
<table><thead><tr><th>Severity</th><th>Category</th><th>Type</th><th>IP</th><th>Description</th><th>#</th><th>First</th><th>Last</th></tr></thead>
<tbody>${rows}</tbody></table>
<footer>LogSentinel Intrusion Detection System — All times in local timezone</footer></body></html>`,'text/html');
  showToast('📄 report.html downloaded');
}

// ── Reset ─────────────────────────────────────────────────────────────────────
export function resetTool() {
  resetState();
  document.getElementById('dashboard').style.display      = 'none';
  document.getElementById('upload-section').style.display = 'block';
  document.getElementById('progress-zone').style.display  = 'none';
  document.getElementById('file-list').innerHTML          = '';
  document.getElementById('analyze-btn').disabled         = true;
  document.getElementById('file-input').value             = '';
}
