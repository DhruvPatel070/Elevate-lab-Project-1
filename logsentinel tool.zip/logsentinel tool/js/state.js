/**
 * state.js
 * Single source of truth for all application state and shared constants.
 * Every module imports from here — never store mutable state locally.
 */

// ─────────────────────────── APPLICATION STATE ────────────────────────────────
export const state = {
  allFiles:        [],          // Raw File objects from the user
  allLines:        [],          // Every raw log line (string[])
  allAlerts:       [],          // Sorted alert objects from detector
  detectedFormats: new Set(),   // e.g. 'Apache Access', 'SSH Auth', 'Firewall'
  activeFilter:    'ALL',       // Current severity filter pill
  activeCatFilter: 'ALL',       // Current attack-category filter
  charts:          {},          // Live Chart.js instances keyed by name
  stats: {                      // Aggregate counters updated after parse
    totalLines: 0, totalEntries: 0, uniqueIPs: 0,
    webRequests: 0, sshEvents: 0, firewallEvents: 0,
    syslogEvents: 0, appEvents: 0, apacheErrors: 0, ostackEvents: 0,
  },
  parsedData: {
    web:        [],   // Apache CLF / Combined / Nginx HTTP entries
    apacheErr:  [],   // Apache error log entries
    ssh:        [],   // SSH auth log entries (failed/accepted/invalid/root)
    syslog:     [],   // Generic syslog + privilege escalation events
    firewall:   [],   // Firewall / iptables / UFW entries
    app:        [],   // Application structured log entries
    openstack:  [],   // OpenStack Nova structured entries
    raw:        [],   // Lines that matched no known format
  },
};

// ─────────────────────────── RESET ───────────────────────────────────────────
export function resetState() {
  state.allFiles        = [];
  state.allLines        = [];
  state.allAlerts       = [];
  state.detectedFormats = new Set();
  state.activeFilter    = 'ALL';
  state.activeCatFilter = 'ALL';
  Object.assign(state.stats, {
    totalLines:0,totalEntries:0,uniqueIPs:0,
    webRequests:0,sshEvents:0,firewallEvents:0,
    syslogEvents:0,appEvents:0,apacheErrors:0,ostackEvents:0,
  });
  Object.values(state.charts).forEach(c => { try { c.destroy(); } catch (_) {} });
  state.charts = {};
  state.parsedData = { web:[],apacheErr:[],ssh:[],syslog:[],firewall:[],app:[],openstack:[],raw:[] };
}

// ─────────────────────────── CONSTANTS ───────────────────────────────────────

/** Known-malicious IPs (offline blacklist — extended list) */
export const BLACKLIST = new Set([
  '185.220.101.33','45.33.32.156','203.0.113.42','198.51.100.0',
  '192.0.2.1','172.16.254.1','89.248.167.131','194.165.16.11',
  '80.82.77.139','80.82.77.33','71.6.146.130','71.6.146.185',
  '71.6.146.186','71.6.165.200','71.6.167.142','71.6.167.143',
  '101.200.81.187','103.56.16.102','104.131.0.69','104.236.198.48',
  '5.188.86.172','14.225.208.190','23.129.64.130','31.184.192.44',
  '36.110.228.254','45.142.212.100','51.75.144.43','62.233.50.246',
  '77.247.108.163','91.108.56.130','109.201.133.100','162.247.72.199',
  '176.10.104.240','185.100.87.202','185.129.62.62','199.87.154.255',
]);

/** Severity order (index = priority) */
export const SEV_ORDER = ['CRITICAL','HIGH','MEDIUM','LOW','INFO'];

/** Attack category metadata */
export const CATEGORIES = {
  BRUTE_FORCE:          { label:'🔥 Brute Force',           color:'#ff3b5c', short:'Brute Force' },
  RECONNAISSANCE:       { label:'🔭 Reconnaissance',         color:'#ff8c00', short:'Recon' },
  DOS:                  { label:'⚡ DoS / Flood',            color:'#ffd700', short:'DoS' },
  EXPLOITATION:         { label:'💉 Exploitation',           color:'#a78bfa', short:'Exploit' },
  PRIVILEGE_ESCALATION: { label:'👑 Privilege Escalation',   color:'#f472b6', short:'PrivEsc' },
  BLACKLISTED_IP:       { label:'🚫 Blacklisted IP',         color:'#ff3b5c', short:'Blacklist' },
  ANOMALY:              { label:'⚠️  Anomaly',               color:'#00d4ff', short:'Anomaly' },
};

/** Suspicious / attack-tool user agents */
export const BAD_AGENTS = /sqlmap|nikto|nmap|masscan|zgrab|nuclei|dirbuster|gobuster|wfuzz|hydra|medusa|nessus|openvas|w3af|acunetix|burpsuite|metasploit|havij|paros|appscan|webinspect|libwww-perl|python-requests\/[0-9]|wget\/[0-9]|curl\/[0-9]|scrapy|mechanize|jakarta|go-http-client\/1/i;

/** SQL injection patterns */
export const SQLI = /(\bUNION\b.{0,40}\bSELECT\b|\bOR\b\s*['"]?1['"]?\s*=\s*['"]?1|'\s*(OR|AND)\s+['"\d]|--\s*(?:$|\s)|;\s*DROP\s+TABLE|;\s*DELETE\s+FROM|xp_cmdshell|EXEC\s*\(|CAST\s*\(|CHAR\s*\(\d|SLEEP\s*\(\d|WAITFOR\s+DELAY|BENCHMARK\s*\(|0x[0-9a-f]{6,}|LOAD_FILE\s*\(|INTO\s+OUTFILE)/i;

/** Cross-site scripting patterns */
export const XSS = /<script[\s>]|javascript\s*:|on\w+\s*=\s*["']?[^"'\s>]|<img[^>]+onerror\s*=|<svg[^>]+onload\s*=|document\.cookie|eval\s*\(|String\.fromCharCode\s*\(|&#x?[0-9a-f]+;|%3[cC]script|alert\s*\(/i;

/** Directory traversal patterns */
export const TRAVERSAL = /(?:\.\.\/){2,}|\.\.\\|%2e%2e[%2f\\]|%252e%252e|\/etc\/(?:passwd|shadow|hosts)|\/proc\/self|\/windows\/system32|boot\.ini|win\.ini/i;

/** Command injection patterns */
export const CMDI = /[;&|`$]\s*(?:ls|cat|id|whoami|uname|wget|curl|bash|sh|python\d?|perl|php|nc|ncat|chmod|chown|dd\s|mkfs|passwd|shadow|echo\s+.+>>?|\/bin\/|\/usr\/bin\/)|cmd\.exe|powershell\.exe|\beval\b.*\$|system\s*\(/i;

/** Encoded attack strings (URL encoding of < > etc) */
export const ENCODED_ATTACK = /%3[cC]%73[cC]ript|%27\s*[oO][rR]\s*%271|%3[cC]img|%2e%2e%2f%2e%2e/i;

/** Sensitive admin paths */
export const ADMIN_PATHS = /\/(?:admin|wp-admin|phpmyadmin|\.env|\.git|config\.php|manager|console|dashboard|cpanel|webmail|cgi-bin|xmlrpc\.php|wp-login\.php|login\.php|administrator|shell|backdoor|c99|r57|cmd)/i;

/** Chart colors */
export const CHART_COLORS = {
  grid:   'rgba(26,58,92,0.4)',
  text:   '#4a7a9b',
  accent: '#00d4ff',
  green:  '#00ff88',
  red:    '#ff3b5c',
  orange: '#ff8c00',
  yellow: '#ffd700',
  pie:    ['#ff3b5c','#ff8c00','#ffd700','#00d4ff','#00ff88','#a78bfa','#f472b6','#34d399','#60a5fa','#fb923c'],
  sev:    { CRITICAL:'#ff3b5c', HIGH:'#ff8c00', MEDIUM:'#ffd700', LOW:'#00d4ff', INFO:'#00ff88' },
  level:  { INFO:'rgba(0,212,255,0.6)',WARNING:'rgba(255,215,0,0.7)',ERROR:'rgba(255,59,92,0.7)',CRITICAL:'rgba(255,59,92,1)',DEBUG:'rgba(100,100,150,0.5)',FATAL:'rgba(255,59,92,1)' },
};
